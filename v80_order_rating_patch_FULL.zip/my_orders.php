<?php
session_start();
include("db_config.php");

$email = $_SESSION['email'];
$result = mysqli_query($conn, "SELECT o.*, i.name, i.image_url FROM orders o JOIN item i ON o.item_id = i.item_id WHERE o.buyer_email = '$email'");
?>

<!DOCTYPE html>
<html>
<head><title>My Orders</title></head>
<body>
<h2>🧾 我的訂單</h2>
<?php while ($row = mysqli_fetch_assoc($result)) { ?>
    <div>
        <img src="<?php echo $row['image_url']; ?>" width="120">
        <p><?php echo $row['name']; ?> - <?php echo $row['order_time']; ?></p>
        <a href="item_detail.php?item_id=<?php echo $row['item_id']; ?>">去評分</a>
    </div><hr>
<?php } ?>
</body>
</html>

<?php
session_start();
include("db_config.php");

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['item_id'])) {
    $item_id = intval($_POST['item_id']);
    $email = $_SESSION['email'];

    $query = "INSERT INTO orders (item_id, buyer_email, order_time) VALUES ($item_id, '$email', NOW())";
    mysqli_query($conn, $query);
    mysqli_query($conn, "UPDATE item SET status = 'sold' WHERE item_id = $item_id");

    header("Location: item_detail.php?item_id=$item_id");
}
?>

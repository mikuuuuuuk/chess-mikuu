<?php
session_start();
include("db_config.php");

$result = mysqli_query($conn, "SELECT * FROM item WHERE status = 'available'");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Item List</title>
    <style>
        .card {
            border: 1px solid #ccc;
            border-radius: 12px;
            padding: 16px;
            width: 200px;
            margin: 10px;
            float: left;
            text-align: center;
        }
        .card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 8px;
        }
    </style>
</head>
<body>
<h2>📦 Browse Items</h2>
<?php while ($row = mysqli_fetch_assoc($result)) { ?>
    <div class="card">
        <img src="<?php echo $row['image_url']; ?>" alt="item">
        <h3><?php echo htmlspecialchars($row['name']); ?></h3>
        <p><?php echo $row['price']; ?> RMB</p>
        <a href="item_detail.php?item_id=<?php echo $row['item_id']; ?>">View</a>
    </div>
<?php } ?>
</body>
</html>

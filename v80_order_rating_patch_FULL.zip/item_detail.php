<?php
session_start();
include("db_config.php");

if (!isset($_GET['item_id'])) {
    echo "No item selected.";
    exit();
}
$item_id = intval($_GET['item_id']);
$result = mysqli_query($conn, "SELECT * FROM item WHERE item_id = $item_id");
$row = mysqli_fetch_assoc($result);

// Check if already ordered
$email = $_SESSION['email'] ?? '';
$order_result = mysqli_query($conn, "SELECT * FROM orders WHERE item_id = $item_id AND buyer_email = '$email'");
$already_ordered = mysqli_num_rows($order_result) > 0;

// Fetch ratings
$ratings_result = mysqli_query($conn, "SELECT * FROM ratings WHERE item_id = $item_id");
?>

<!DOCTYPE html>
<html>
<head><title>Item Detail</title></head>
<body>
    <h2><?php echo $row['name']; ?></h2>
    <img src="<?php echo $row['image_url']; ?>" width="300"><br>
    <p><?php echo $row['description']; ?></p>
    <p>Price: <?php echo $row['price']; ?> RMB</p>

    <?php if (!$already_ordered && $row['status'] === 'available') { ?>
        <form method="POST" action="place_order.php">
            <input type="hidden" name="item_id" value="<?php echo $item_id; ?>">
            <button type="submit">🛒 下單</button>
        </form>
    <?php } elseif ($already_ordered) { ?>
        <p style="color:green;">✅ 已購買</p>
        <form method="POST" action="submit_rating.php">
            <label>星星評分 (1~5):</label>
            <input type="number" name="stars" min="1" max="5" required><br>
            <label>留言:</label><br>
            <textarea name="comment"></textarea>
            <input type="hidden" name="item_id" value="<?php echo $item_id; ?>">
            <input type="hidden" name="buyer_email" value="<?php echo $email; ?>">
            <button type="submit">送出評價</button>
        </form>
    <?php } else { ?>
        <p>此商品已售出。</p>
    <?php } ?>

    <h3>⭐ 評論列表</h3>
    <?php while ($r = mysqli_fetch_assoc($ratings_result)) { ?>
        <div>
            <strong><?php echo $r['buyer_email']; ?>:</strong>
            <?php echo str_repeat("⭐", $r['stars']); ?><br>
            <?php echo $r['comment']; ?>
        </div><hr>
    <?php } ?>
</body>
</html>

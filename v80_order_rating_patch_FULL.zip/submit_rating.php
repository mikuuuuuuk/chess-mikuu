<?php
include("db_config.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $item_id = intval($_POST['item_id']);
    $email = $_POST['buyer_email'];
    $stars = intval($_POST['stars']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    $sql = "INSERT INTO ratings (item_id, buyer_email, stars, comment, rating_time)
            VALUES ($item_id, '$email', $stars, '$comment', NOW())";

    mysqli_query($conn, $sql);
    header("Location: item_detail.php?item_id=$item_id");
}
?>
